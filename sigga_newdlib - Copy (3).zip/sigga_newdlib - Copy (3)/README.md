Welcome to dLib!

*DLIB IS NOT MEANT FOR ENTRY-LEVEL PROGRAMMERS*

dLib is a fully modular library meant for VEX robotics.
dLib comes with PID and odometry, but it is easy to create new stuff for the PID and odometry such as gain scheduling or feed-forward.

i jerk my shit in public 
